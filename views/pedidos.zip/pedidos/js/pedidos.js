const d = document;
const w = window;
let valores = "";
d.addEventListener("DOMContentLoaded", async (e) => {
  e.preventDefault();
  valores = window.location.search;

  Listar_clientes();
  Listar_tipos_trazabilidad();
  Listar_pedidos();
  // Función para expandir o contraer nodos
  const checkboxes = document.querySelectorAll('.tree input[type="checkbox"]');
  checkboxes.forEach((checkbox) => {
    checkbox.addEventListener("change", function () {
      const ul = this.parentElement.querySelector("ul");
      if (ul) {
        ul.style.display = this.checked ? "block" : "none";
      }
    });
  });

  d.addEventListener("change", async (e) => {
    if (e.target.matches(".chk_trazabilidad") || e.target.matches(".chk_trazabilidad *")) {
      let padre = e.target.parentElement.parentElement;
      let chktrazabilidad = padre.querySelectorAll(".chk_trazabilidad");
      // Itera sobre la lista de checkboxes
      for (var i = 0; i < chktrazabilidad.length; i++) {
        var checkbox = chktrazabilidad[i];
        var valor = chktrazabilidad[i].value;
        // Hacer algo con cada checkbox, por ejemplo, verificar si está marcado
        // Verifica si el checkbox está marcado o desmarcado
        if (checkbox.checked) {
          let data = new FormData();
          data.append("id", valor);
          await fetch($("#id_url_ajax").val() + "pedidos/Listar_Opciones", {
            method: "POST",
            cache: "no-cache",
            body: data,
          })
            .then((res) => (res.ok ? res.json() : Promise.reject(res)))
            .catch((error) => {
              alert(JSON.stringify(error.length) || "Error al cargar tipo de detalle");
            })
            .then((response) => {
              let template_detalle = "";
              response.forEach((element) => {
                template_detalle += `
                  <div class="checkbox">
                    <label>
                        <input type="checkbox" class="chk_detalle" id="chk_detalle[]" name="chk_detalle[]" value="${element.id}" style="transform: scale(1.5);margin-right: 5px;"><label style="font-weight: 600;color: #777777;">${element.nombre_opcion}</label>
                    </label>
                  </div>
                  `;
                d.getElementById("list_detalle" + valor).innerHTML = template_detalle;
              });
            });
        } else {
          d.getElementById("list_detalle" + valor).innerHTML = "";
        }
      }
    }
  });

  d.addEventListener("change", async (e) => {
    if (e.target.matches("#referencia")) {
      let padre = e.target.parentElement.parentElement;
      let data = new FormData();
      data.append("referencia", padre.querySelector("#referencia").value);
      await fetch($("#id_url_ajax").val() + "pedidos/validar_numero_referencia", {
        method: "POST",
        cache: "no-cache",
        body: data,
      })
        .then((res) => (res.ok ? res.json() : Promise.reject(res)))
        .catch((error) => {
          alert(JSON.stringify(error.length) || "Error al cargar tipo de detalle");
        })
        .then((response) => {
          console.log(response);
        });
    }
  });

  d.addEventListener("click", async (e) => {
    if (e.target.matches("#guardar_trazabilidad") || e.target.matches("#guardar_trazabilidad *")) {
      let mensaje = "";
      if (d.getElementById("clientes").value === "") {
        mensaje = `
              <div class="alert alert-warning alert-icon alert-icon-border alert-dismissible" role="alert">
                  <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
                  <div class="message">
                    <button class="close" type="button" data-dismiss="alert" aria-label="Close"><span class="mdi mdi-close" aria-hidden="true"></span></button>
                    <strong>Mensaje!</strong> Debe seleccionar un cliente para realiziar el pedido.
                  </div>
              </div>`;
        d.getElementById("notificaciones").innerHTML = mensaje;
        d.getElementById("clientes").focus();
      } else if (d.getElementById("referencia").value === "") {
        mensaje = `
        <div class="alert alert-warning alert-icon alert-icon-border alert-dismissible" role="alert">
            <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="message">
              <button class="close" type="button" data-dismiss="alert" aria-label="Close"><span class="mdi mdi-close" aria-hidden="true"></span></button>
              <strong>Mensaje!</strong> Debe diligenciar un numero de referencia para realiziar el pedido.
            </div>
        </div>`;
        d.getElementById("notificaciones").innerHTML = mensaje;
        d.getElementById("referencia").focus();
        d.getElementById("ref").classList.add("has-warning");
      } else if (d.getElementById("chk_trazabilidad[]").checked === false) {
        mensaje = `
        <div class="alert alert-warning alert-icon alert-icon-border alert-dismissible" role="alert">
            <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="message">
              <button class="close" type="button" data-dismiss="alert" aria-label="Close"><span class="mdi mdi-close" aria-hidden="true"></span></button>
              <strong>Mensaje!</strong> Debe seleccionar al menos una opcion de trazabilidad para realiziar el pedido.
            </div>
        </div>`;
        d.getElementById("notificaciones").innerHTML = mensaje;
        d.getElementById("ref").classList.remove("has-warning");
      } else {
        d.getElementById("ref").classList.remove("has-warning");
        if (w.confirm("¿Esta seguro de guardar el pedido?")) {
          let cliente = d.getElementById("clientes").value;
          let referencia = d.getElementById("referencia").value;
          let observacion = d.getElementById("observacion").value;
          let tipos = d.getElementsByName("chk_trazabilidad[]");
          let detalles = d.getElementsByName("chk_detalle[]");
          let datos = {
            tipo: [],
          };
          let datos_detalle = {
            detalle: [],
          };

          for (var i = 0; i < tipos.length; i++) {
            var checkbox = tipos[i];
            if (checkbox.checked) {
              var tipo_traz = tipos[i].value;
              // datos.tipo[i] = tipo_traz;
              datos.tipo.push(tipo_traz);
            } else {
              datos.tipo.splice(i, 1); // Elimina el elemento no seleccionado
              // i--; // Ajusta el índice para evitar problemas con el cambio de longitud del array
            }
          }
          var nota = datos;
          nota = JSON.stringify(nota);

          for (let j = 0; j < detalles.length; j++) {
            // const element = detalles[j];
            var checkbox_detalle = detalles[j];
            if (checkbox_detalle.checked) {
              var detalles_traz = detalles[j].value;
              // datos_detalle.detalle[j] = detalles_traz;
              datos_detalle.detalle.push(detalles_traz);
            } else {
              datos_detalle.detalle.splice(j, 1); // Elimina el elemento no seleccionado
              // j--; // Ajusta el índice para evitar problemas con el cambio de longitud del array
            }
          }
          var nota_detalle = datos_detalle;
          nota_detalle = JSON.stringify(nota_detalle);

          let data = new FormData();
          data.append("cliente", cliente);
          data.append("referencia", referencia);
          data.append("observacion", observacion);
          data.append("nota", nota);
          data.append("nota_detalle", nota_detalle);

          await fetch($("#id_url_ajax").val() + "pedidos/Insertar_trazabilidad_pedido", {
            method: "POST",
            body: data,
            cache: "no-cache",
          })
            .then((res) => (res.ok ? res.json() : Promise.reject(res)))
            .then((response) => {
              if (response.numero === 200) {
                mensaje = `
                <div class="alert alert-success alert-icon alert-icon-border alert-dismissible" role="alert">
                    <div class="icon"><span class="mdi mdi-check"></span></div>
                    <div class="message">
                      <button class="close" type="button" data-dismiss="alert" aria-label="Close"><span class="mdi mdi-close" aria-hidden="true"></span></button>
                      <strong>Mensaje!</strong> ${response.mensaje}
                    </div>
                </div>`;
                $("#crear_trazabilidad").modal("hide");
              } else {
                mensaje = `
                <div class="alert alert-danger alert-icon alert-icon-border alert-dismissible" role="alert">
                    <div class="icon"><span class="mdi mdi-info-outline"></span></div>
                    <div class="message">
                      <button class="close" type="button" data-dismiss="alert" aria-label="Close"><span class="mdi mdi-close" aria-hidden="true"></span></button>
                      <strong>Mensaje!</strong> ${response.mensaje}
                    </div>
                </div>`;
              }
              d.getElementById("mensaje").innerHTML = mensaje;
              // location.reload();
              setTimeout(function () {
                location.reload(false);
              }, 1500);
            })
            .catch((error) => {
              alert(JSON.stringify(error.length) || "Error al insertar la trazabilidad");
            });
          // alert("Cliente: " + cliente + " referencia: " + referencia + " observacion: " + observacion + " tipo: " + nota + " detalles " + nota_detalle);
        }
      }
    }
  });
});

async function Listar_clientes() {
  await fetch($("#id_url_ajax").val() + "pedidos/Listar_Clientes", {
    method: "POST",
    cache: "no-cache",
  })
    .then((res) => (res.ok ? res.json() : Promise.reject(res)))
    .catch((error) => {
      alert(JSON.stringify(error.length) || "Error al cargar los Clientes");
    })
    .then((response) => {
      let CLIENTES = d.getElementById("clientes");
      response.forEach((value) => {
        let {id, documento, nombre} = value;
        let opt = document.createElement("option");
        opt.value = id;
        // opt.textContent = documento + " | " + nombre;
        opt.textContent = nombre;
        CLIENTES.appendChild(opt);
      });
    });
}

async function Listar_tipos_trazabilidad() {
  await fetch($("#id_url_ajax").val() + "pedidos/Listar_tipos_Seguimiento", {
    method: "POST",
    cache: "no-cache",
  })
    .then((res) => (res.ok ? res.json() : Promise.reject(res)))
    .catch((error) => {
      alert(JSON.stringify(error.length) || "Error al cargar los tipos de trazabilidad");
    })
    .then((response) => {
      let template = "";
      response.forEach((element) => {
        template += `
          <div class="panel panel-default">
            <div class="panel-heading" style="height:30px;display: flex;align-items: center;">
              <h4 class="panel-title">
                <input type="checkbox" id="chk_trazabilidad[]" name="chk_trazabilidad[]" class="chk_trazabilidad" value="${element.id}" style="transform: scale(1.5);margin-right: 5px;margin-bottom:15px;">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse${element.id}">${element.nombre_tipo}</a>
              </h4>
            </div>
            <div id="collapse${element.id}" class="panel-collapse collapse">
              <div class="panel-body">
                <div style="margin-left: 5px;" id="list_detalle${element.id}"></div>
              </div>
            </div>
          </div>
        `;
        d.getElementById("accordion").innerHTML = template;
      });
    });
}

async function Listar_pedidos() {
  await fetch($("#id_url_ajax").val() + "pedidos/Listar_pedidos", {
    method: "POST",
    cache: "no-cache",
  })
    .then((res) => (res.ok ? res.json() : Promise.reject(res)))
    .catch((error) => {
      alert(JSON.stringify(error.length) || "Error al cargar los tipos de trazabilidad");
    })
    .then((response) => {
      let template = "";
      let tbody = d.getElementById("body_pedidos");
      response.forEach((element) => {
        const fila = d.createElement("tr");
        const columnaNumdoc = d.createElement("td");
        columnaNumdoc.textContent = element.numdoc;
        const columnaReferencia = d.createElement("td");
        // columnaReferencia.textContent = element.referencia;
        columnaReferencia.innerHTML = `<a href="${$("#id_url_ajax").val()}pedidos/detalle/${element.numdoc}/${valores}">${element.referencia}</a>`;
        // columnaReferencia.innerHTML = `<a href="${$("#id_url_ajax").val()}pedidos/detalle?numdoc=${element.numdoc}/${valores}">${
        //   element.referencia
        // }</a>`;
        const columnaCliente = d.createElement("td");
        columnaCliente.textContent = element.nombre;
        const columnaFecha = d.createElement("td");
        columnaFecha.textContent = element.fecha_creacion;
        const columnaEstado = d.createElement("td");
        columnaEstado.textContent = element.estado;

        fila.appendChild(columnaNumdoc);
        fila.appendChild(columnaReferencia);
        fila.appendChild(columnaCliente);
        fila.appendChild(columnaFecha);
        fila.appendChild(columnaEstado);
        tbody.appendChild(fila);
      });
    });
}
